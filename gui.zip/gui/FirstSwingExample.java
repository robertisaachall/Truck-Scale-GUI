import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.awt.Graphics;
import java.awt.geom.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


public class FirstSwingExample extends JFrame implements ActionListener {
  
  JFrame frame;
  JList drivers;
  String[] driversList;

  public void paint(final Graphics g) {
    super.paintComponents(g);
    final Graphics2D g2 = (Graphics2D) g;
    final Line2D line = new Line2D.Float(1, 80, 1600, 80);
    g2.draw(line);

  }
  public String[] readFromFile()
  {
    ArrayList<String> drivers = new ArrayList<String>();
    try (BufferedReader br = new BufferedReader(new FileReader("C:/Users/Robert's Laptop/Documents/School and programs/Classes/CPSC1010/Class Work/Final project/random_names.txt")))
        {

            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) {
             drivers.add(sCurrentLine);
            }

        } catch (final IOException e) {
            e.printStackTrace();
        } 
      String[] array = new String[drivers.size()];
      return drivers.toArray(array);
  }
  public FirstSwingExample()
  {
    frame = new JFrame("test");// creating instance of JFrame
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Creating New Driver Button.
    

    final JButton newDriverButton = new JButton("New Driver");// creating instance of JButton
    newDriverButton.setBounds(5, 5, 150, 40);// x axis, y axis, width, height
    newDriverButton.setToolTipText("Used for inserting a new driver.");
    newDriverButton.addActionListener(this);

    final JButton clearDriverListButton = new JButton("Remove driver(s).");
    clearDriverListButton.setBounds(160, 5, 200, 40);
    clearDriverListButton.setToolTipText("Clears the driver list. Proceed at caution this will delete.");
    clearDriverListButton.addActionListener(this);

    final JPanel panel = new JPanel();
    String[] names = readFromFile();
    drivers = new JList(names);
    JScrollPane scrollDrivers = new JScrollPane(drivers);
    scrollDrivers.setBounds(1380,45, 150,800);


    JLabel driverListInformation = new JLabel("Drivers:");
    driverListInformation.setBounds(1420,5,75, 40);
    
    



    
    
    frame.add(newDriverButton);
    frame.add(clearDriverListButton);
    panel.add(scrollDrivers);
    frame.add(driverListInformation);
    frame.add(panel);
    panel.setLayout(null);

    frame.setSize(1600, 900);// 400 width and 500 height
    frame.setVisible(true);// making the frame visible


  }

public void actionPerformed(final ActionEvent e) 
    { 
        final String s = e.getActionCommand(); 
        if (s.equals("New Driver"))
        { 
         // boolean correctInput = false;
        //  do
        //  {
            final JPanel input = new JPanel();
            final JTextField testField = new JTextField(5);
            input.add(testField);
            final int name = JOptionPane.showConfirmDialog(null, input,"Enter information for new driver.",JOptionPane.OK_CANCEL_OPTION);
            if(name == JOptionPane.OK_OPTION)
            {
              /*
              drivers = new JList(driversList);
              JScrollPane scrollDrivers = new JScrollPane(drivers);
              scrollDrivers.setBounds(1380,45, 150,800);
              panel.add(scrollDrivers);
              */
              
            }
         // }while(correctInput == false);
        } 
        else if(s.equals("Remove driver(s)."))  
        {
            // create a dialog Box 
            final JDialog d = new JDialog(frame, "dialog Box"); 
  
            // create a label 
            final JLabel l = new JLabel("test"); 
  
            d.add(l); 
  
            // setsize of dialog 
            d.setSize(100, 100); 
  
            // set visibility of dialog 
            d.setVisible(true); 
        }
    } 
  

  public static void main(final String[] args)
  {
        final FirstSwingExample test = new FirstSwingExample();

  }  
}  