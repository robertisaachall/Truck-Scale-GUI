
package truckscale;

import java.util.Scanner;

public class CostumerInformationTester {
    /* main class body//

 
/*@Creator: Joseph Edwards
*@date:20/1/3
*@Version Alpha
*@ID: tyv379
*@side note:there are still a few bugs i am aware of and am working on.
*/
    
    
    public static void main(String[] args) {
       

CustomerInformation[] customer = new CustomerInformation[1];
        Scanner in = new Scanner(System.in);
/* this for loop is for the collection of the customer information
        this allows for a more customer friendly and interactive input*/
        for (int i = 0; i<customer.length; i++) {
            System.out.println("please enter you name: ");
            String customerName = in.nextLine();
            System.out.println("please enter your age: ");
           int customerAge = in.nextInt();
            System.out.println("Please enter your Email: ");
            String customerEmail = in.next();
            System.out.println("Please enter your zip code: ");
            int customerAddress = in.nextInt();
            
            System.out.println("How many miles do you plan on Driving? ");
           
            System.out.println("Please enter a Phone Number: ");
           Long customerNumber = in.nextLong();
            customer[i] = new CustomerInformation(customerName , customerAddress, customerEmail, customerNumber, customerAge);
            
        }
for (CustomerInformation customerInfo: customer){
    System.out.printf("customer Name: %10s\n" + "customer Age: %10d\n" + "customer Address: %10d\n" + "customer Email: %10s\n" + "customer Number: %10f\n"
    ,customerInfo.getCustomerName() ,customerInfo.getCustomerAge(), customerInfo.getCustomerAddress(), customerInfo.getCustomerEmail(), customerInfo.getCustomerNumber());
    /**@return this statement takes the information displayed by the user and returns the values typed in by them*/
    
     
}}}