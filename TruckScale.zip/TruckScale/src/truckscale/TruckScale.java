
package truckscale;

/**
 *
 * @author Joseph Edwards
 * @ID:tyv379
 * @Date:02/19/2020
 * @version: 1.0
 */
public class TruckScale {
public static final double TRUCKCLASSA = 80;
public static final double TRUCKCLASSB = 120;
public static final double TRUCKCLASSC = 180;
private double truckWeight;
private double truckSize;
private double axelNumber;
private double toPrice;
private String truckClass;
//private double toTruck;


    
    public TruckScale(double newWeight, double newSize, double newAxel, String x,double newTemp)//, double finalPrice)
    {
        truckWeight = newWeight;
        truckSize = newSize;
        axelNumber = newAxel;
        toPrice = newTemp;
        truckClass = x;
        //toTruck = finalPrice;
        
        
        
    }
        public TruckScale()
    {
        truckWeight = 18000.0;
        truckSize = 11.0;
        axelNumber = 3.0;
        
    }
    public void setTruckWeight(double newWeight)
    {
        this.truckWeight = newWeight;
    }
    public double getTruckWeight()
    {
        return truckWeight;
    }
    public void setTruckSize(double newSize)
    {
        this.truckSize = newSize;
    }
    public double getTruckSize()
    {
        return truckSize;
    }
    public void setAxelNumber(double newAxel)
    {
        this.axelNumber = newAxel;
    }
    public double getAxelNumber()
    {
        return axelNumber;
    }
    
    public void setPrice(double price)
    {
        this.toPrice = price;
    }
    
    public double getPrice()
    {
        return this.toPrice;
    }
 
    public String determineClass()
    {
        String x = "failed";
        if(truckClass.equalsIgnoreCase("a"))
        {
            x = "Class A";
        }
        else if(truckClass.equalsIgnoreCase("b"))
        {
            x = "Class B";
        }
        else if(truckClass.equalsIgnoreCase("c"))
        {
            x = "Class C";
        }
        else
        {
            x = "Invalid Input.";
        }
        return x;
    }
    
    
    
    
    
    public double toFinal()
    {
       
        if(truckClass.equalsIgnoreCase("a"))
        {
            setPrice(((getTruckWeight()/getAxelNumber()) * (getTruckSize()/TRUCKCLASSA)));
        
        }
        else if(truckClass.equalsIgnoreCase("b"))
        {
            setPrice(((truckWeight/axelNumber) * (truckSize/TRUCKCLASSB)));
            
        }
        else if(truckClass.equalsIgnoreCase("c"))
        {
            setPrice(((truckWeight/axelNumber) * (truckSize/TRUCKCLASSC)));
        }
        else{
            System.out.println("Please enter an accepted truck class");
        }
        
        return getPrice();

  }
    
    public double returnFinal()
    {
        double idiot = getPrice();
        return idiot;
    }
}