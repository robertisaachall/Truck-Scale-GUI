
package truckscale;

/*@Creator: Joseph Edwards
*@date:20/1/3
*@Version Alpha
*@ID: tyv379
*@side note:there are still a few bugs i am aware of and am working on.
*/


public class CustomerInformation {
/**
 * These are the variables for the class
 */
    public String customerName;
    public long customerNumber;
    public int customerAddress;
    public String customerEmail;
    public int customerAge;
        /**
         * this constructor sets the values of customer names to the temporary values. 
         * 
         * 
     * @param newName
     * @param newAddress
     * @param newEmail
     * @param newNumber
     * @param newAge
         */
        public CustomerInformation(String newName, int newAddress, String newEmail, long newNumber, int newAge){
        
         customerName = newName;
         customerAddress = newAddress;
         customerEmail = newEmail;
         customerNumber = newNumber;
         customerAge = newAge;
         
     }

     // this getter returns the customerName.
     public String getCustomerName()
     
     {
         return customerName;
         
     }
    
    // this setter makes the customer name equal to the name set by the user
     public void setCustomerName(String newName)
     {
         customerName = newName;  
     }
     
    // This getter returns the customer's address
     public int getCustomerAddress()
     {
         return customerAddress;
     }
     // This setter sets the customer's address to the address specified by the customer
     public void setCustomerAddress(int newAddress)
     {
         customerAddress = newAddress;
     }
     // This getter retrieves the customer email from the system
     public String getCustomerEmail()
     {
         return customerEmail;
     }
     // This setter changes the customer email to the email written by the user
     public void setCustomerEmail(String newEmail)
     {
         customerEmail = newEmail;
     }
     // This getter is made getting the customer number
     public float getCustomerNumber()
     {
         return customerNumber;
     }
     // This setter is made for setting the customer number to the specified number
     public void setCustomerNumber(long newNumber)
     {
         customerNumber = (int) newNumber;

     }
     public int getCustomerAge(){
         return customerAge;
     }
public void setCustomerAge(int newAge){
    customerAge = newAge;
     }}