
package truckscale;
/*
*@author: Joesph Edwards
*@version:Alpha
*@date:20/1/3
*@side note:work in progress
*@ID:tyv379
*/
import java.util.Scanner;

public class TruckScaleTester {
    public static void main(String [] args){

        Scanner in = new Scanner(System.in);





        System.out.println("What is your is the total weight of your current truck?");
        double newWeight = in.nextDouble();
        System.out.println("What is the current lenght of your truck?");
        double newSize = in.nextDouble();
        System.out.println("how many axels does your truck possess?");
        double newAxel = in.nextDouble();
        System.out.println("What is the class of your truck:\n Class A: Straight Truck\n Class B:Cab Over \n Class C: Full Cab");
        String x = in.next();

        TruckScale TS = new TruckScale(newWeight,newSize,newAxel,x,0.0);



        System.out.printf("your truck weight is: %10.0f\n" + "your truck length is: %10.0f\n" + "your registered number of axels are: %10.0f\n" + "class of truck: %10s\n" + "price: %10.3f\n"
                ,TS.getTruckWeight() ,TS.getTruckSize(), TS.getAxelNumber(), TS.determineClass(), TS.toFinal());


    }
}